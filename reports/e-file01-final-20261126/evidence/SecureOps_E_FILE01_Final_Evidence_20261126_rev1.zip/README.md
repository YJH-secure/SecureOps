# SecureOps E FILE-01 최종 증거 묶음

기준 소스: E 2d776a52faf692f13ebca2f00a591bcfa805b8fb, C 2fac2a02edb1edf08cf4435138f4a1d543e33ba2, 고정 C Bridge SHA-256 497ac6a21270f517ad94041dcd7769eef3aa2a1c16b956df81e931fb1d698714.
D Core 기준 SHA 0cab3a247d2143fc5556e37f6651440e109eef70의 Git 객체는 로컬에서 확인되지 않아 commit/tree 연결은 미확인이다. D callback 전달본의 SHA-256은 4812dc4da5b660fbc5e4eb5c349905f6ccc28cbdcd8b0acb7b949d9c0f26ad58이다.

## 증거 범위

- D callback과 E/C MOCK 교차 검증: E/C 266개와 D callback 38개, 총 304개 PASS. FAIL, ERROR, SKIP은 0으로 기록됨.
- D04 정상 원상복구 및 D05 실패 롤백 선택 재실행은 각각 1 PASS. 304개에 포함된 테스트 ID의 재실행이므로 새 고유 테스트로 합산하지 않음.
- SSH-01 화면 3장은 MOCK 실행 결과, FILE-01 화면 2장은 D04/D05 결과 JSON을 요약해 출력한 캡처임. FILE-01 캡처는 실시간 테스트 화면이 아님.
- 실제 VM, SSH 접속, OS 파일 권한 변경은 수행하지 않음. 유효 C Bridge 입력에서 permissions.error가 생성되는 동작도 검증되지 않음.

## 파일 구성

- verification/304: 결과 요약, 검증 보고서, E266 실행 로그, D01-D38 개별 결과와 원본 실행 로그.
- verification/selected/D04-D05: 실제 전달 D callback을 사용한 두 선택 재실행의 로그와 JSON.
- presentation/screenshots: 기존 발표 캡처 5장.

SHA256SUMS.csv는 각 파일의 원본 및 공유본 SHA-256을 함께 기록한다. 개인 계정 이름이 포함된 텍스트 사본은 공유본에서만 익명화했다. 원본은 변경하지 않았다. CSV 자체와 ZIP 자체 해시는 별도 전달 정보로 기록한다.

## ?? ?? ??

2026-11-26 ?? ?? ???? D Core ?? commit `0cab3a247d2143fc5556e37f6651440e109eef70`? ??? `core/main.py`, `core/storage.py`, `core/cvss_validation.py`, `core/cvss_assessment.py`, `core/cvss.py`, JSON Schema ?? 6?? blob ??? ?????. ??? D callback ? ???? ?? commit tree ?? ?? ?? tree? ???? ??? ??? ???? ???. ?? `results.json`? `object_available_locally: false`? 2026-11-25 ?? ?? ????, ? ?? ??? ???? ??? ?? ?? ??? ???? ???.
