# D FILE-01 `permissions.error` 독립 검증 보고서

검증일: 2026-11-25  
범위: 전달된 D callback 보완본을 고정 E/C 소스와 결합한 오프라인 MOCK 검증. 실제 SSH·VM 변경은 수행하지 않음.

### 12:52 추가 요청에 따른 범위 제한

이번 교차 검증은 E의 phase별 오류 보고서 누락 여부와 rollback 상태 표현의 적정성을 평가하지 않는다. D32·D33 테스트는 전달된 전체 D01–D38 테스트 묶음의 실행 결과에 포함되지만, 해당 필드의 완전성·표현 방식에 대한 별도 판정이나 개선 검증으로 확대하지 않았다. 기존 계약 테스트에서 확인하는 `permissions.error`의 조치 성공 오판 방지 및 실패 처리 동작은 검증 범위에 유지한다.

## 판정

**전달된 D callback 및 E/C MOCK 동작은 독립 격리 환경에서 통과했다.** 수정 전 callback 원본을 찾아 11/24 보고서에 적힌 SHA와 일치함을 확인했고, 수정 후 callback과의 diff도 확인했다. 다만 D Core 기준 커밋 `0cab3a247d2143fc5556e37f6651440e109eef70`의 Git 객체는 로컬에 없어, callback이 해당 commit tree에서 파생됐는지는 **미확인**이다. 이번 결과를 D Core commit 기준의 완전한 독립 재현으로 표현하면 안 된다.

## 기준 및 전달 파일

| 항목 | SHA-256 / 상태 |
|---|---|
| E 기준 | `2d776a52faf692f13ebca2f00a591bcfa805b8fb`; 고정 checkout에서 확인 |
| D Core 기준 | `0cab3a247d2143fc5556e37f6651440e109eef70`; 로컬 Git 객체 없음 |
| C 기준 | `2fac2a02edb1edf08cf4435138f4a1d543e33ba2`; 파일럿 제공 자료 기준 |
| C Bridge | `497ac6a21270f517ad94041dcd7769eef3aa2a1c16b956df81e931fb1d698714`; 일치 |
| 전달 `file01_mock_callback.py` | `4812dc4da5b660fbc5e4eb5c349905f6ccc28cbdcd8b0acb7b949d9c0f26ad58`; 요청 해시와 일치 |
| 수정 전 `Downloads\file01_mock_callback.py 수정전.py` | `9a350942aa77ace1c66379917479695507416d6e6a2a2253a164a31b73a5dea0`; 11/24 report.md 기재값 및 실제 파일 해시 일치 |
| 전달 `test_file01_mock_callback.py` | `ea09f0c096ad5d9b28250ceeaf3d11c7d5137bda72ec47e616ce44a080347ec1`; 요청 해시와 일치 |
| 수정 전 `Downloads\1124\test_file01_mock_callback.py` | `41c87cad41de07744d1aba409f0fa3a3c75fcc81522f254fb6d35f0cc0ae3eca`; 11/24 report.md 기재값과 일치 |
| `changes.diff` | `e8d70c89f8cfc791726b3d0aa8ed246f13f2355380ccf17e753e8b7d2158408e` |
| `report.md 1125.md` | `8b16db27a35e2c9d482f20aa77644ab37e9636dee703b45d365ea492987a85ee` |

수정 전 테스트 원본(386줄)과 수정 후 전달 테스트(538줄)를 대조했다. 기존 D01–D28 테스트 본문(첫 384줄)은 동일하고, 기존 `__main__` 가드는 새 테스트 뒤로 이동된 상태로 동일하다. 변경분은 테스트 끝에 D29–D38을 추가한 152줄이다. 따라서 **확보한 원본 테스트 기준으로 기존 D01–D28 테스트 코드가 유지됨을 확인**했다.

수정 전 callback은 `Downloads\file01_mock_callback.py 수정전.py`에서 찾았다. 실제 SHA가 `1124\report.md`의 수정 전 SHA와 일치한다. 수정 전·후 파일 diff는 `_result()`의 `permissions.error` 허용 분기 7줄 추가뿐이며 전달 `changes.diff`의 코드 변경과 일치한다. 앞서 첨부된 Pasted text는 이 수정 전 callback과 마지막 개행 유무만 달라 바이트 해시는 다르다. Downloads 내 ZIP 28개에서는 callback 또는 테스트 파일 보관본을 찾지 못했지만 별도 수정 전 파일이 확인되어 ZIP 검색은 기준선 확인에 더 이상 필요하지 않다.

고정 C 의존 파일:

- `checks/system/file_check.py`: `26c2ed2c553e4031317933af512e887739be5601cf22dd54fdf416685dc29cd2`
- `checks/system/result_adapter.py`: `50388632296bc54c5ed26fe902472373f5076b95a208745722afb6888802b539`
- Bridge: 위 고정 SHA와 일치. 격리 환경은 해당 고정 C 파일을 사용했으며, 다른 사본의 `file_check.py`는 사용하지 않음.

## 독립 테스트 결과

### 전달 D callback 테스트

명령:

```powershell
python -B -X utf8 -m unittest discover -s tests -p test_file01_mock_callback.py -v
```

작업 디렉터리: 격리 검증본의 `src`. `PYTHONPATH`는 격리된 `src`, 고정 Bridge 경로 및 기존 의존성 overlay로 설정. Python `3.12.14`, `jsonschema 4.26.0`. 종료 코드 0.

| 구간 | 결과 |
|---|---:|
| D01–D28 | 28 PASS |
| D29–D38 | 10 PASS |
| 합계 | **38 PASS, 0 FAIL, 0 ERROR, 0 SKIP** |

원본 로그: `verification/304/D01-D38/D01-D38.log`  
테스트별 JSON: 같은 디렉터리의 `test_D01_...json`부터 `test_D38_...json`까지.

### 기존 E/C 회귀 묶음

최종 유효 로그 기준 합계는 **266 PASS, 0 FAIL, 0 ERROR, 0 SKIP**, 모든 최종 명령 종료 코드 0이다. 52개 CVSS 테스트는 266개 합계 안에 포함되며 별도 추가 합산하지 않는다.

| 묶음 | 테스트 수 | 최종 로그 |
|---|---:|---|
| E v1.1 | 22 | `verification/304/logs/E266/01-v11.log` |
| D/E v1.1 | 2 | `verification/304/logs/E266/02-de-v11.retry.log` |
| E v1.2 | 18 | `verification/304/logs/E266/03-v12.log` |
| 실행 계층 | 19 | `verification/304/logs/E266/04-execution.log` |
| CVSS / JSON v1.2 | 52 | `verification/304/logs/E266/05-cvss.log` |
| B 계약 | 4 | `verification/304/logs/E266/06-b-contract.log` |
| 재진단 이력 | 20 | `verification/304/logs/E266/07-recheck-history.log` |
| 실행 이력 저장소 | 18 | `verification/304/logs/E266/08-history-store.log` |
| 승인 | 10 | `verification/304/logs/E266/09-approval.log` |
| 버전 호환 | 10 | `verification/304/logs/E266/10-versions.log` |
| 정책 | 12 | `verification/304/logs/E266/11-policy.retry.log` |
| 방화벽 | 17 | `verification/304/logs/E266/12-firewall.retry.log` |
| 로그 | 12 | `verification/304/logs/E266/13-log.retry.log` |
| 기존 파일럿 | 14 | `verification/304/logs/E266/14-old-pilot.retry.log` |
| C Bridge | 10 | `verification/304/logs/E266/15-c-bridge.retry.log` |
| callback binding | 8 | `verification/304/logs/E266/16-callback-binding.log` |
| FILE-01 F01–F18 | 18 | `verification/304/logs/E266/F01-F18-retry1.log` |

최초 환경 구성 시 `F01-F18.log`, `02-de-v11.log`, `11-policy.log`에 각각 import 경로 누락, D 소스 환경변수 누락, Git 기준 조회 환경 문제로 실패/skip 기록이 있다. 환경만 보정한 재실행 로그가 위 표의 `retry` 파일이며 통과했다. 초기 로그를 지우거나 성공으로 바꾸지 않았고, 최종 통과 건수는 재실행 로그만으로 계산했다.

**총 고유 테스트 수: 304** (D callback D01–D38 38개 + 기존 회귀 묶음 266개). 이름이 다른 D callback 테스트와 회귀 묶음을 더한 수이며, CVSS 52개는 266개 안에 포함된다.

## 계약 영향 판단

- **유효한 `permissions.error` 보존:** D29–D33 합성 fixture에서 C 결과 및 전체 v1.2 보고서 필드가 보존됨.
- **손상된 입력 저장 전 차단:** D34–D36에서 필수 근거·wrapper·CVSS·필수 결과 오류는 예외 처리되어 D 저장 경로로 진행하지 않음.
- **기존 신뢰 경계 유지:** D35에서 승인, before digest, phase, snapshot identity/mode 검증을 우회하지 않음.
- **저장 책임:** D38에서 callback 내부 저장소 생성/save/load 호출 0회. D30에서 E adapter의 save/load와 전체 dict 동일성 검증을 확인.
- **성공 오판 방지 및 실패 처리:** D31에서 `after`의 유효 `permissions.error`가 조치 성공으로 판정되지 않는 동작을 확인. 오류 보고서의 세부 phase별 필드 완전성이나 rollback 상태 표현의 적정성은 이번 교차 검증에서 평가하지 않음.
- **고정 Bridge와 합성 fixture 구분:** D29–D36은 합성 `permissions.error` fixture다. 고정 Bridge의 유효 입력(0666/0644)은 D37에서 `permissions.error`를 만들지 않음. 실제 Bridge에서 발생한 error를 검증한 것이 아님.
- **E 코드 변경 필요 여부:** 이번 전달 변경의 동작을 E 고정 소스에서 검증하는 데 E 코드 수정은 필요하지 않았음. 이는 이 callback 보완 범위에 대한 결론이며 실제 운영 연동 승인은 별도임.
- **기존 결과 필드 한계:** E의 `outcome`, `rollback`, 최종 상태 필드는 변경되지 않았으며 이번 보완으로 세분화되지 않음.

## 검증 한계와 후속 확인

1. 기존 로컬 Git 저장소들에서 D Core 기준 SHA의 commit 객체를 찾지 못함. 따라서 전달 callback이 해당 commit tree에서 파생됐는지 확인할 수 없음.
2. 수정 전·후 callback 파일 해시 및 diff는 확인했지만, D Core commit/tree 객체가 없어 해당 수정의 D 커밋 이력 포함 여부는 검증할 수 없음.
3. 이번 실행은 제공된 callback 소스, E 고정 checkout, 고정 C Bridge를 결합한 오프라인 독립 검증이다. D Core에 실제 반영되거나 실제 D 저장소와 통합된 검증은 아님.
4. 실제 SSH, VM, 파일 권한 변경 및 운영 환경 동작은 검증하지 않음.
5. E phase별 오류 보고서 누락 여부 및 rollback 상태 표현 문제는 요청에 따라 검토 범위에서 제외함. 기존 D32·D33 테스트는 테스트 묶음 실행 건수에는 포함되나, 해당 쟁점에 관한 별도 결론은 내리지 않음.

수정 전 callback 및 테스트 원본 대조는 완료했다. D Core 기준 commit/tree 객체 또는 접근 가능한 고정 원격 소스가 확보되면 callback이 기준선에 적용된 최종 변경인지 commit/tree 기준으로 확인할 수 있다.

## 증거 파일

- D 테스트 로그: `verification/304/D01-D38/D01-D38.log`
- D 테스트별 산출물: `verification/304/D01-D38/test_D01_*.json` … `test_D38_*.json`
- E/C 회귀 로그: `verification/304/logs/E266/`의 표에 명시한 최종 실행 로그
- 파일 SHA-256 목록: `evidence-sha256.txt` (이 보고서와 결과 JSON은 순환 해시를 피하기 위해 제외)



### 2026-11-26 ?? ?? ??

? ???? 2026-11-25 ?? ??? ?? ?? ??? ????. ?? D Core ?? commit `0cab3a247d2143fc5556e37f6651440e109eef70`? ??? `core/main.py`, `core/storage.py`, `core/cvss_validation.py`, `core/cvss_assessment.py`, `core/cvss.py`, JSON Schema ?? 6?? blob ??? ?????. ?? callback????? ? commit tree ?? ?? ?? tree? ?????? ?????.
